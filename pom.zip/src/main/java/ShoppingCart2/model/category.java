package ShoppingCart2.model;

import javax.persistence.*;
import org.springframework.stereotype.Component;

 @Table
 @Entity
 @Component
public class category {
	 @Id
		@GeneratedValue
		private int catid;
		@Column
		private String catname;		public int getCatid() {
			return catid;
		}
		public void setCatid(int catid) {
			this.catid = catid;
		}
		public String getCatname() {
			return catname;
		}
		public void setCatname(String catname) {
			this.catname = catname;
		}


		
	}


