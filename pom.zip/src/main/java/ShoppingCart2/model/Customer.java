package ShoppingCart2.model;

import javax.persistence.*;

import org.springframework.stereotype.Component;

@Table
@Entity
@Component
public class Customer {

	@Id
	@GeneratedValue
	private int cid;
	@Column
	private String cname;
	@Column
	private String cpass;
	@Column
	private String cphno;
	@Column
	private String caddr;
	@Column
	private String role;
	@Column
	private boolean enabled;
	public int getCid() {
		return cid;
	}
	public void setCid(int cid) {
		this.cid = cid;
	}
	public String getCname() {
		return cname;
	}
	public void setCname(String cname) {
		this.cname = cname;
	}
	public String getCpass() {
		return cpass;
	}
	public void setCpass(String cpass) {
		this.cpass = cpass;
	}
	public String getCphno() {
		return cphno;
	}
	public void setCphno(String cphno) {
		this.cphno = cphno;
	}
	public String getCaddr() {
		return caddr;
	}
	public void setCaddr(String caddr) {
		this.caddr = caddr;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public boolean isEnabled() {
		return enabled;
	}
	public void setEnabled(boolean enabled) {
		this.enabled = enabled;
	}
	
}
