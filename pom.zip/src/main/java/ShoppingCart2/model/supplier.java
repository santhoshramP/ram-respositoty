package ShoppingCart2.model;

import javax.persistence.*;
import org.springframework.stereotype.Component;

@Table
@Entity
@Component

public class supplier {
	@Id
	@GeneratedValue
	private int sid;
	@Column
	private String sname;
	public int getSid() {
		return sid;
	}
	public void setSid(int sid) {
		this.sid = sid;
	}
	public String getSname() {
		return sname;
	}
	public void setSname(String sname) {
		this.sname = sname;
	}



	
}






 
 
