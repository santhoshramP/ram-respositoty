package ShoppingCart2.model;

import javax.persistence.*;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

@Table
@Entity
@Component

public class Product {

	@Id
	@GeneratedValue
	private int pid;
	@Column
	private String pname;
	@Column
	private String pprice;
	@Column
	private String pcat;
	@Transient
	private MultipartFile file;
	
	public int getPid() {
		return pid;
	}
	public void setPid(int pid) {
		this.pid = pid;
	}
	public String getPname() {
		return pname;
	}
	public void setPname(String pname) {
		this.pname = pname;
	}
	public String getPprice() {
		return pprice;
	}
	public void setPprice(String pprice) {
		this.pprice = pprice;
	}
	public String getPcat() {
		return pcat;
	}
	public void setPcat(String pcat) {
		this.pcat = pcat;
	}
	public MultipartFile getFile() {
		return file;
	}
	public void setFile(MultipartFile file) {
		this.file = file;
	}

	
}

	


