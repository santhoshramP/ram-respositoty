package ShoppingCart2.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import ShoppingCart2.dao.productDAO;
import ShoppingCart2.model.Product;

@Service
public class Productservice {
	@Autowired
	productDAO pd;
	
	
	public void addproduct(Product p){
		pd.addProduct(p);
	}
	
	public void delproduct(int id){
		pd.delProduct(id);
	}

	public void updproduct(Product p){
		pd.upProduct(p);
	}
	
	public Product getproductById(int id){
		return pd.getProductById(id);
	}
	
	public List<Product> getAllproducts(){
		return pd.getAllProducts();
	}

}


