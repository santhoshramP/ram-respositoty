package ShoppingCart2.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import ShoppingCart2.dao.CustomerDAO;
import ShoppingCart2.model.Customer;

@Service
public class CustomerService {

	@Autowired
	CustomerDAO cd;
	
	public void addCustomer(Customer c){
		cd.addCustomer(c);
	}
	
	public void delCustomer(int id){
		cd.delCustomer(id);
	}
	
	public void updCustomer(Customer c){
		cd.updCustomer(c);
	}
	
	public Customer getCustomerById(int id){
		return cd.getCustomerById(id);
	}
	
	public List<Customer> getAllCustomers(){
		return cd.getAllCustomers();
	}
}
