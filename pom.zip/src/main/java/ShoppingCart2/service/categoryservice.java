package ShoppingCart2.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import ShoppingCart2.dao.categoryDAO;
import ShoppingCart2.model.category;

@Service
public class categoryservice {
		
		
		@Autowired
		categoryDAO cd;
		
		public void   addcategory(category c){
	    	cd.addCategory(c);
	    }
	    
	    public void delcategory(int id){
	    	cd.delCategory(id);
	    }
	    
	    public void updcategory(category c){
	    	cd.updCategory(c);
	    }
	    
	    public category getcategoryId(int id){
	    	return cd.getCategoryById(id);
	    }
	    
	    public List<category> getAllcategory(){
	    	return cd.getAllCategory();
	    }



	}


