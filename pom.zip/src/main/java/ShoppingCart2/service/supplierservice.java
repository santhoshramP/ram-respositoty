package ShoppingCart2.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import ShoppingCart2.dao.supplierDAO;
import ShoppingCart2.model.supplier;

@Service
public class supplierservice {
	
	
	@Autowired
	supplierDAO sd;
	
	
	public void addsupplier(supplier s){
		sd.addsupplier(s);
	}
	
	public void delsupplier(int id){
		sd.delsupplier(id);
	}
	
	public void updsupplier(supplier s){
		sd.updsupplier(s);
	}
	
	public supplier getsupplierById(int id){
		return sd.getsupplierById(id);
	}
	
	public List<supplier> getAllsupplier(){
		return sd.getAllsuppliers();
	}

}
