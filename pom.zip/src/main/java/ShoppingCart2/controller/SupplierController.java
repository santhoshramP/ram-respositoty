package ShoppingCart2.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import ShoppingCart2.model.supplier;
import ShoppingCart2.service.supplierservice;

@Controller
public class SupplierController {

	@Autowired
	supplierservice ss;
	
	ModelAndView m;
	
	@ModelAttribute("supobj")
	public supplier gets(){
		return new supplier();
	}
	
	@RequestMapping("/viewsupl")
	public ModelAndView viewSupl(){
		m = new ModelAndView("");
		List<supplier> l = ss.getAllsupplier();
		m.addObject("sall", l);
		return m;
	}
	
	@RequestMapping("/addsup")
	public String addsup(){
		return "";
	}
	
	@RequestMapping(value="/add1",method=RequestMethod.POST)
	public ModelAndView addsup1(@ModelAttribute("supobj")supplier s,BindingResult br){
		m = new ModelAndView();
		ss.addsupplier(s);
		return m;
	}
	
	@RequestMapping("/sinfo/{id}")
	public ModelAndView getprod(@PathVariable("id")int id){
		m = new ModelAndView("");
		m.addObject("oldobj", ss.getsupplierById(id));
		return m;
	}

	@RequestMapping("/delsup/{id}")
	public ModelAndView delprod(@PathVariable("id")int id){
		m = new ModelAndView("");
		ss.delsupplier(id);
		return m;
	}

	@RequestMapping("/updsup")
	public ModelAndView updprod(@ModelAttribute("oldobj")supplier s){
		m = new ModelAndView("");
		ss.updsupplier(s);
		return m;
	}
	
}
