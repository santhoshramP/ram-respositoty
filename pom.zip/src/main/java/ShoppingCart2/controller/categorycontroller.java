package ShoppingCart2.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;


import ShoppingCart2.model.category;
import ShoppingCart2.service.categoryservice;

@Controller
public class categorycontroller {
	
	@Autowired
	categoryservice cs;
	
	ModelAndView m;
	
	@ModelAttribute("c1obj")
	public category getc1(){
		return new category();
	}
	@RequestMapping("/addc1")
	public ModelAndView addc1(@ModelAttribute("c1obj")category c1){
		m = new ModelAndView("c1index");
		cs.addcategory(c1);
		return m;
	}
	
	@RequestMapping("/c1info/{id}")
	public ModelAndView getCust(@PathVariable("id")int id){
		m = new ModelAndView("updateCategory");
		m.addObject("oldobj", cs.getcategoryId(id));
		return m;
	}
	
	@RequestMapping("/delc1/{id}")
	public ModelAndView delCust(@PathVariable("id")int id){
		m = new ModelAndView("c1index");
		cs.delcategory(id);
		return m;
	}
	
	@RequestMapping("/updc1")
	public ModelAndView updCust(@ModelAttribute("oldobj")category c){
		m = new ModelAndView("c1index");
		cs.updcategory(c);
		return m;
	}
	
	@RequestMapping("")
	public ModelAndView viewAllCats(){
		m = new ModelAndView();
		List<category> l = cs.getAllcategory();
		m.addObject("call", l);
		return m;
	}
}

	
	
	





