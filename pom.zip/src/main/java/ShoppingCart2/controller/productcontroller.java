package ShoppingCart2.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;


import ShoppingCart2.model.Product;
import ShoppingCart2.service.Productservice;

@Controller
public class productcontroller {
	@Autowired
	Productservice ps;
	
	
	ModelAndView m;
	
	@ModelAttribute("pobj")
	public Product getp(){
		return new Product();
	}
	@RequestMapping("/addprod")
   public ModelAndView addprod(@ModelAttribute("pobj")Product p){
	m = new ModelAndView("pindex");
	ps.addproduct(p);
	return m;
}

@RequestMapping("/pinfo/{id}")
public ModelAndView getprod(@PathVariable("id")int id){
	m = new ModelAndView("updateproduct");
	m.addObject("oldobj", ps.getproductById(id));
	return m;
}

@RequestMapping("/delprod/{id}")
public ModelAndView delprod(@PathVariable("id")int id){
	m = new ModelAndView("index");
	ps.delproduct(id);
	return m;
}

@RequestMapping("/updprod")
public ModelAndView updprod(@ModelAttribute("oldobj")Product p){
	m = new ModelAndView("pindex");
	ps.updproduct(p);
	return m;
}
}
