package ShoppingCart2.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import ShoppingCart2.model.Customer;

@Repository
public class CustomerDAO {

	@Autowired
	SessionFactory sf;
	
	Session s;
	Transaction t;
	Customer x;
	
	public void addCustomer(Customer c){
		s = sf.getCurrentSession();
		t = s.beginTransaction();
		c.setRole("ROLE_USER");
		c.setEnabled(true);
		s.save(c);
		t.commit();
	}
	
	public void delCustomer(int id){
		s = sf.getCurrentSession();
		t = s.beginTransaction();
		x = (Customer)s.load(Customer.class, id);
		s.delete(x);
		t.commit();
	}
	
	public void updCustomer(Customer c){
		s = sf.getCurrentSession();
		t = s.beginTransaction();
		x = (Customer)s.load(Customer.class, c.getCid());
		x.setCname(c.getCname());
		x.setCaddr(c.getCaddr());
		x.setCpass(c.getCpass());
		s.saveOrUpdate(x);
		t.commit();
	}
	
	public Customer getCustomerById(int id){
		s = sf.getCurrentSession();
		t = s.beginTransaction();
		x = (Customer)s.load(Customer.class, id);
		t.commit();
		return x;
	}
	
	@SuppressWarnings("unchecked")
	public List<Customer> getAllCustomers(){
		s = sf.getCurrentSession();
		t = s.beginTransaction();
		List<Customer> l = s.createCriteria(Customer.class).list();
		t.commit();
		return l;
	}
}
