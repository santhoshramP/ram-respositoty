package ShoppingCart2.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import ShoppingCart2.model.Product;

@Repository


public class productDAO{
	
  @Autowired
  SessionFactory sf;
  Session s;
  Transaction t; 
  Product x;
  
  public void addProduct (Product p){
	    s = sf.getCurrentSession();
		t = s.beginTransaction();
		s.save(p);
		t.commit();
	}
  public void delProduct(int id){
		s = sf.getCurrentSession();
		t = s.beginTransaction();
		x = (Product)s.load(Product.class, id);
		s.delete(x);
		t.commit();
	}
	
	public void upProduct(Product p){
		s = sf.getCurrentSession();
		t = s.beginTransaction();
		x = (Product)s.load(Product.class, p.getPid());
		x.setPname(p.getPname());
		x.setPprice (p.getPprice());
		x.setPcat(p.getPcat());
		s.saveOrUpdate(x);
		t.commit();
	}
	
	public Product getProductById(int id){
		s = sf.getCurrentSession();
		t = s.beginTransaction();
		x = (Product)s.load(Product.class, id);
		t.commit();
		return x;
	}
	
	@SuppressWarnings("unchecked")
	public List<Product> getAllProducts(){
		s = sf.getCurrentSession();
		t = s.beginTransaction();
		List<Product> l = s.createCriteria(Product.class).list();
		t.commit();
		return l;
	}
}


