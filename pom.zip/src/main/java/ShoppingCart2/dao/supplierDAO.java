package ShoppingCart2.dao;

import java.util.List;


import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;


import ShoppingCart2.model.supplier;
@Repository

public class supplierDAO {
	@Autowired
	SessionFactory sf;
	
	Session s;
	Transaction t;
	 supplier x;
	
	 public void addsupplier  (supplier s1){
		    s = sf.getCurrentSession();
			t = s.beginTransaction();
			s.save(s1);
			t.commit();
		}
	public void delsupplier(int id){
		s = sf.getCurrentSession();
		t = s.beginTransaction();
		x = (supplier)s.load(supplier.class, id);
		s.delete(x);
		t.commit();
	}
	
	public void updsupplier(supplier s1){
		s = sf.getCurrentSession();
		t = s.beginTransaction();
		x = (supplier)s.load(supplier.class, s1.getSid());
		x.setSname(s1.getSname());
		s.saveOrUpdate(x);
		t.commit();
	}
	
	public supplier getsupplierById(int id){
		s = sf.getCurrentSession();
		t = s.beginTransaction();
		x = (supplier)s.load(supplier.class, id);
		t.commit();
		return x;
	}
	
	@SuppressWarnings("unchecked")
	public List<supplier> getAllsuppliers(){
		s = sf.getCurrentSession();
		t = s.beginTransaction();
		List<supplier> l = s.createCriteria(supplier.class).list();
		t.commit();
		return l;
	}
}


