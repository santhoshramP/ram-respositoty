package ShoppingCart2.dao;


import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;


import ShoppingCart2.model.category;

@Repository
public class categoryDAO {
	@Autowired
	SessionFactory sf;
	Session s;
	Transaction t;
	category x;
	public void addCategory(category c){
		s = sf.getCurrentSession();
		t = s.beginTransaction();
		s.save(c);
		t.commit();
	}
	
	public void delCategory(int id){
		s = sf.getCurrentSession();
		t = s.beginTransaction();
		x = (category)s.load(category.class, id);
		s.delete(x);
		t.commit();
	}
	
	public void updCategory(category c){
		s = sf.getCurrentSession();
		t = s.beginTransaction();
		x = (category)s.load(category.class, c.getCatid() );
		x.setCatname(c.getCatname());
		s.saveOrUpdate(x);
		t.commit();
	}
	
	public category getCategoryById(int id){
		s = sf.getCurrentSession();
		t = s.beginTransaction();
		x = (category)s.load(category.class, id);
		t.commit();
		return x;
	}
	
	@SuppressWarnings("unchecked")
	public List<category> getAllCategory(){
		s = sf.getCurrentSession();
		t = s.beginTransaction();
		List<category> l = s.createCriteria(category.class).list();
		t.commit();
		return l;
	}
}

	


