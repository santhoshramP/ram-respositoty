package ShoppingCart.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class homecontroller {

	
	
	@RequestMapping("/")
		public String goh(){
		return"index";
	}
	
	@RequestMapping("/home")
		public String goh1(){
		return"home";
	}
		@RequestMapping("/login")
		public String goh3(){
		return"login";
	}
	@RequestMapping("/register")
public String goh2(){
return"register";
}
}